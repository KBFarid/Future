![dayz](https://user-images.githubusercontent.com/101267251/199025890-32a51d41-d8a8-4b80-98fd-5324ee5708c3.jpg)


# DayZ-ExpansionTrader-Renegade
Expansion Market files forRenegade mod
